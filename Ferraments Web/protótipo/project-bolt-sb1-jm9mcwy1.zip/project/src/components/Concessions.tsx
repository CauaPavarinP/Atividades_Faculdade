import { Popcorn, Coffee, Candy, ShoppingCart } from 'lucide-react';

const concessions = [
  {
    id: 1,
    name: 'Pipoca Pequena',
    description: 'Pipoca quentinha e crocante',
    price: 12.00,
    icon: Popcorn,
    image: 'https://images.pexels.com/photos/7991319/pexels-photo-7991319.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: 2,
    name: 'Pipoca Média',
    description: 'Ideal para compartilhar',
    price: 18.00,
    icon: Popcorn,
    image: 'https://images.pexels.com/photos/4662438/pexels-photo-4662438.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: 3,
    name: 'Pipoca Grande',
    description: 'Para os fãs de pipoca',
    price: 24.00,
    icon: Popcorn,
    image: 'https://images.pexels.com/photos/4662439/pexels-photo-4662439.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: 4,
    name: 'Refrigerante 500ml',
    description: 'Bebida gelada',
    price: 10.00,
    icon: Coffee,
    image: 'https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: 5,
    name: 'Refrigerante 1L',
    description: 'Bebida gelada tamanho família',
    price: 16.00,
    icon: Coffee,
    image: 'https://images.pexels.com/photos/2775860/pexels-photo-2775860.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
  {
    id: 6,
    name: 'Combo Especial',
    description: 'Pipoca G + 2 Refris',
    price: 42.00,
    icon: Candy,
    image: 'https://images.pexels.com/photos/3678136/pexels-photo-3678136.jpeg?auto=compress&cs=tinysrgb&w=400',
  },
];

export default function Concessions() {
  return (
    <section id="bomboniere" className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Bomboniere</h2>
          <p className="text-slate-400 text-lg">Complete sua experiência com nossos deliciosos produtos</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {concessions.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="bg-slate-900 rounded-xl overflow-hidden hover:shadow-2xl hover:shadow-orange-500/10 transition-all duration-300 group"
              >
                <div className="aspect-video overflow-hidden relative">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
                  <div className="absolute top-4 right-4 bg-orange-500 p-2 rounded-lg">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-white font-bold text-xl mb-2">{item.name}</h3>
                  <p className="text-slate-400 text-sm mb-4">{item.description}</p>

                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-orange-500">
                      R$ {item.price.toFixed(2)}
                    </span>
                    <button className="bg-orange-600 hover:bg-orange-700 text-white p-3 rounded-lg transition-all hover:scale-110">
                      <ShoppingCart className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-gradient-to-r from-red-600 to-orange-600 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Combo Família</h3>
          <p className="text-white/90 mb-6">2 Pipocas Grandes + 4 Refrigerantes + 2 Chocolates</p>
          <div className="flex items-center justify-center gap-4">
            <span className="text-3xl font-bold text-white">R$ 89,90</span>
            <button className="bg-white text-red-600 font-bold px-8 py-3 rounded-lg hover:bg-slate-100 transition-colors">
              Adicionar ao Carrinho
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
