import { Film, MapPin, Phone, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Film className="w-8 h-8 text-red-500" />
              <span className="text-2xl font-bold text-white">CineMax</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              A melhor experiência cinematográfica com tecnologia de ponta e conforto incomparável.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#filmes" className="text-slate-400 hover:text-white transition-colors text-sm">
                  Filmes em Cartaz
                </a>
              </li>
              <li>
                <a href="#ingressos" className="text-slate-400 hover:text-white transition-colors text-sm">
                  Ingressos
                </a>
              </li>
              <li>
                <a href="#bomboniere" className="text-slate-400 hover:text-white transition-colors text-sm">
                  Bomboniere
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Horários</h4>
            <ul className="space-y-2 text-slate-400 text-sm">
              <li>Segunda a Quinta: 14h - 23h</li>
              <li>Sexta a Domingo: 12h - 00h</li>
              <li>Feriados: 12h - 00h</li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-slate-400 text-sm">
                <MapPin className="w-4 h-4 text-red-500" />
                Av. Cinema, 1234 - Centro
              </li>
              <li className="flex items-center gap-2 text-slate-400 text-sm">
                <Phone className="w-4 h-4 text-red-500" />
                (11) 1234-5678
              </li>
              <li className="flex items-center gap-2 text-slate-400 text-sm">
                <Mail className="w-4 h-4 text-red-500" />
                contato@cinemax.com.br
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center">
          <p className="text-slate-400 text-sm">
            © 2026 CineMax. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
