import { Film, Ticket, Popcorn, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Film className="w-8 h-8 text-red-500" />
            <span className="text-2xl font-bold text-white">CineMax</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#filmes" className="text-slate-300 hover:text-white transition-colors flex items-center gap-2">
              <Film className="w-4 h-4" />
              Filmes
            </a>
            <a href="#ingressos" className="text-slate-300 hover:text-white transition-colors flex items-center gap-2">
              <Ticket className="w-4 h-4" />
              Ingressos
            </a>
            <a href="#bomboniere" className="text-slate-300 hover:text-white transition-colors flex items-center gap-2">
              <Popcorn className="w-4 h-4" />
              Bomboniere
            </a>
          </div>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <a href="#filmes" className="block text-slate-300 hover:text-white transition-colors">
              Filmes
            </a>
            <a href="#ingressos" className="block text-slate-300 hover:text-white transition-colors">
              Ingressos
            </a>
            <a href="#bomboniere" className="block text-slate-300 hover:text-white transition-colors">
              Bomboniere
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}
