import { Sparkles } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-red-950/20 to-transparent"></div>

      <div className="max-w-7xl mx-auto relative">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-red-400" />
            <span className="text-red-400 text-sm font-medium">Agora em Cartaz</span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6">
            Viva a Magia do
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500">
              Cinema
            </span>
          </h1>

          <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-8 leading-relaxed">
            A melhor experiência cinematográfica da cidade. Salas modernas, som envolvente e um catálogo incrível de filmes.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#ingressos"
              className="px-8 py-4 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-all hover:scale-105 hover:shadow-lg hover:shadow-red-500/20"
            >
              Comprar Ingressos
            </a>
            <a
              href="#filmes"
              className="px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-lg transition-all hover:scale-105"
            >
              Ver Filmes
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
