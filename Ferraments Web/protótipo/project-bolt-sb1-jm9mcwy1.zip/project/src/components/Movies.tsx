import { Clock, Star } from 'lucide-react';

const movies = [
  {
    id: 1,
    title: 'O Último Horizonte',
    genre: 'Ficção Científica',
    duration: '148 min',
    rating: 4.8,
    image: 'https://images.pexels.com/photos/7991319/pexels-photo-7991319.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 2,
    title: 'Segredos da Noite',
    genre: 'Suspense',
    duration: '122 min',
    rating: 4.5,
    image: 'https://images.pexels.com/photos/7991274/pexels-photo-7991274.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 3,
    title: 'Além das Estrelas',
    genre: 'Aventura',
    duration: '135 min',
    rating: 4.9,
    image: 'https://images.pexels.com/photos/7991047/pexels-photo-7991047.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 4,
    title: 'Corações em Chamas',
    genre: 'Romance',
    duration: '110 min',
    rating: 4.3,
    image: 'https://images.pexels.com/photos/7234221/pexels-photo-7234221.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

export default function Movies() {
  return (
    <section id="filmes" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Em Cartaz</h2>
          <p className="text-slate-400 text-lg">Escolha seu próximo filme favorito</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {movies.map((movie) => (
            <div
              key={movie.id}
              className="group relative bg-slate-900 rounded-xl overflow-hidden hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-red-500/10"
            >
              <div className="aspect-[2/3] overflow-hidden">
                <img
                  src={movie.image}
                  alt={movie.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex items-center gap-1 bg-yellow-500/20 px-2 py-1 rounded">
                    <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                    <span className="text-yellow-500 text-sm font-semibold">{movie.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-400 text-sm">
                    <Clock className="w-3 h-3" />
                    {movie.duration}
                  </div>
                </div>

                <h3 className="text-white font-bold text-lg mb-1">{movie.title}</h3>
                <p className="text-slate-400 text-sm mb-3">{movie.genre}</p>

                <button className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-2 rounded-lg transition-colors">
                  Comprar Ingresso
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
