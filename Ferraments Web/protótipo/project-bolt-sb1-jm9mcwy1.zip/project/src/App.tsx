import Header from './components/Header';
import Hero from './components/Hero';
import Movies from './components/Movies';
import Concessions from './components/Concessions';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-950">
      <Header />
      <Hero />
      <Movies />
      <Concessions />
      <Footer />
    </div>
  );
}

export default App;
